var msg = 'Hello world';
console.log(msg);
