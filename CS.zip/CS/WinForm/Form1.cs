namespace WinForm;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
        
        this.Name = "Form1";
        this.Text = "Form1";
        this.Size = new System.Drawing.Size(1000, 600);
        this.StartPosition = FormStartPosition.CenterScreen;
    }
}
