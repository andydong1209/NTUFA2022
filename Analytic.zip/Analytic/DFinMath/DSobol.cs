using System;

namespace DFinMath
{
    /// <summary>
    /// When n is negative, internally initializes a set of MAXBIT direction 
    ///   numbers for each of MAXDIM different Sobol sequences. 
    /// When n is positive but less than MAXDIM, returns as the vector x[0..n-1]
    ///   the next values from n of these sequences. 
    /// (n must not be changed between initializations.)
    /// </summary>
    public class Sobseq
    {
        public Sobseq()
        {
            ix = new ulong[MAXDIM];
            iu = new ulong[MAXBIT, MAXDIM];
            iv = new ulong[MAXBIT * MAXDIM];
            iv[0] = 1;   iv[1] = 1;  iv[2] = 1;   iv[3] = 1;
            iv[4] = 1;   iv[5] = 1;  iv[6] = 3;   iv[7] = 1;   iv[8] = 3;
            iv[9] = 3;   iv[10] = 1; iv[11] = 1;  iv[12] = 5;  iv[13] = 7;
            iv[14] = 7;  iv[15] = 3; iv[16] = 3;  iv[17] = 5;  iv[18] = 15;
            iv[19] = 11; iv[20] = 5; iv[21] = 15; iv[22] = 13; iv[23] = 9;
        }
        private int MAXBIT = 30;
        private int MAXDIM = 6;
        private double fac;
        private ulong in0;
        private ulong[] ix;
        private ulong[,] iu;
        private ulong[] mdeg = { 1, 2, 3, 3, 4, 4 };
        private ulong[] ip = { 0, 1, 1, 2, 1, 4 };
        private ulong[] iv;

        public void sobseq(int n, double[] x)
        {
            int j, k, l;
            ulong i, im, ipp;

            if (n < 0)
            {
                for (k = 0; k < MAXDIM; k++) ix[k] = 0;
                in0 = 0;
                if (iv[0] != 1) return;
                fac = 1.0 / (1L << MAXBIT);
                for (j = 0; j < MAXBIT; j++)
                    for (k = 0; k < MAXDIM; k++) 
                        iu[j, k] = iv[MAXDIM * j + k];
                for (k = 0; k < MAXDIM; k++)
                {
                    for (j = 0; j < (int)mdeg[k]; j++) 
                        iu[j, k] <<= (MAXBIT - j - 1);
                    for (j = (int)mdeg[k]; j < MAXBIT; j++)
                    {
                        ipp = ip[k];
                        i = iu[j - (int)mdeg[k], k];
                        i ^= (i >> (int)mdeg[k]);
                        for (l = (int)mdeg[k] - 1; l >= 1; l--)
                        {
                            if ((ipp & 1) != 0) i ^= iu[j - l, k];
                            ipp >>= 1;
                        }
                        iu[j, k] = i;
                    }
                }
            }
            else
            {
                im = in0++;
                for (j = 0; j < MAXBIT; j++)
                {
                    if ((im & 1) == 0) break;
                    im >>= 1;
                }
                if (j > MAXBIT - 1)
                {
                    try
                    {
                        throw new Exception();
                    }
                    catch (Exception)
                    {
                        throw new ApplicationException("MAXBIT too small in sobseq invalid method");
                    }
                }
                im = (ulong)(j * MAXDIM);
                for (j = 0; j < MAXBIT; j++)
                {
                    for (k = 0; k < MAXDIM; k++) 
                        iv[MAXDIM * j + k] = iu[j, k];
                }
                for (k = 0; k < Math.Min(n, MAXDIM); k++)
                {
                    ix[k] ^= iv[(int)im + k];
                    x[k] = ix[k] * fac;
                }
            }
        }
    }
}
